package testing;

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import modelo.*;
import excepciones.*;

public class PedidoTest {

	@Test
    public void testGetPedidoEnCurso() throws PedidoTotalExcedidoException {
        Pedido pedido = new Pedido("Felipe", "Titán Plaza", true, 8, new ArrayList<>());
        assertTrue(pedido.getPedidoEnCurso());
    }

    @Test
    public void testCerrarPedido() throws PedidoTotalExcedidoException {
        Pedido pedido = new Pedido("Felipe", "Titán Plaza", true, 8, new ArrayList<>());
        pedido.cerrarPedido();
        assertFalse(pedido.getPedidoEnCurso());
    }

    @Test
    public void testGetDireccionCliente() throws PedidoTotalExcedidoException {
        Pedido pedido = new Pedido("Felipe", "Titán Plaza", true, 8, new ArrayList<>());
        assertEquals("123 Main St", pedido.getDireccionCliente());
    }

    @Test
    public void testGetItemsPedido() throws PedidoTotalExcedidoException {
        ArrayList<Producto> itemsPedido = new ArrayList<>();
        itemsPedido.add(new ProductoMock("Producto 1", 100));
        itemsPedido.add(new ProductoMock("Producto 2", 200));
        Pedido pedido = new Pedido("Felipe", "Titán Plaza", true, 8, itemsPedido);
        assertEquals(itemsPedido, pedido.getItemsPedido());
    }

    @Test
    public void testGetIdPedido() throws PedidoTotalExcedidoException {
        Pedido pedido = new Pedido("Felipe", "Titán Plaza", true, 8, new ArrayList<>());
        assertEquals(1, pedido.getIdPedido());
    }

    @Test
    public void testAgregarProducto() throws PedidoTotalExcedidoException {
        Pedido pedido = new Pedido("Felipe", "Titán Plaza", true, 8, new ArrayList<>());
        ProductoMock producto = new ProductoMock("Producto 1", 100);
        pedido.agregarProducto(producto);
        assertTrue(pedido.getItemsPedido().contains(producto));
    }

    @Test(expected = PedidoTotalExcedidoException.class)
    public void testAgregarProducto_ExceededTotal() throws PedidoTotalExcedidoException {

    	ArrayList<Producto> itemsPedido = new ArrayList<>();
        itemsPedido.add(new ProductoMock("Producto 1", 100000));
        Pedido pedido;
        try {
            pedido = new Pedido("Felipe", "Titán Plaza", true, 8, itemsPedido);
            Producto producto = new ProductoMock("Producto 2", 60000);
            pedido.agregarProducto(producto);
            fail("Se esperaba PedidoTotalExcedidoException");
        } catch (PedidoTotalExcedidoException e) {
            
        }
    }

    @Test
    public void testGuardarFactura() throws IOException, PedidoTotalExcedidoException {
        File facturaFile = new File("Facturas/1.txt");
        if (facturaFile.exists()) 
        {
		facturaFile.delete();
		}
		Pedido pedido = new Pedido("Felipe", "Titán Plaza", true, 8, new ArrayList<>());
		
		pedido.guardarFactura();
		

		assertTrue(facturaFile.exists());
    }
}
   

