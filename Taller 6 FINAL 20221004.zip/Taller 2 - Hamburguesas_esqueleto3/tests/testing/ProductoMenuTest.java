package testing;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;

import modelo.*;

public class ProductoMenuTest {

	@Test
    public void testGenerarTextoFactura() {
		
        String nombre = "Hamburguesa";
        int precioBase = 100;
        ProductoMenu productoMenu = new ProductoMenu(nombre, precioBase);

        String textoFactura = productoMenu.generarTextoFactura();

        assertEquals("Hamburguesa: 100", textoFactura);
    }

}
