package excepciones;

import modelo.Producto;

public class ProductoRepetidoException extends HamburguesaException {
	public ProductoRepetidoException(Producto producto) {
        super("Durante la carga, se encontró que el ingrediente " + producto.getNombre() + " está repetido.");
    }
}
