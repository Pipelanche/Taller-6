package excepciones;

public class HamburguesaException extends Exception {
	
    public HamburguesaException(String mensaje) {
        super(mensaje);
    }
}
