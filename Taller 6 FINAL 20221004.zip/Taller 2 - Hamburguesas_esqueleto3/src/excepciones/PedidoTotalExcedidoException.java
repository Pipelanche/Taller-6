package excepciones;

import modelo.Pedido;

public class PedidoTotalExcedidoException extends HamburguesaException {
	
	public PedidoTotalExcedidoException(Pedido pedido) {
		super("El valor total del pedido de " + pedido.getNombrecliente() + " supera los 150,000 pesos.");
    }
}
