package testing;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;

import modelo.*;

public class ComboTest {

	@Test
    public void testAgregarItemACombo() {
		
        ProductoMenu itemCombo = new ProductoMenu("Hamburguesa", 100);
        ArrayList<ProductoMenu> itemsCombo = new ArrayList<>();
        Combo combo = new Combo("Combo 1", 0.2, itemsCombo);

        combo.agregarItemACombo(itemCombo);
        ArrayList<ProductoMenu> actualItemsCombo = combo.getItemsCombo();

        assertEquals(1, actualItemsCombo.size());
        assertEquals(itemCombo, actualItemsCombo.get(0));
    }
	
	@Test
    public void testGetPrecio() {

        ArrayList<ProductoMenu> itemsCombo = new ArrayList<>();
        itemsCombo.add(new ProductoMenu("Hamburguesa 1", 100));
        itemsCombo.add(new ProductoMenu("Hamburguesa 2", 150));
        Combo combo = new Combo("Combo 1", 0.2, itemsCombo);

        int precio = combo.getPrecio();

        assertEquals(200, precio);
    }

    @Test
    public void testGenerarTextoFactura() {

        ArrayList<ProductoMenu> itemsCombo = new ArrayList<>();
        itemsCombo.add(new ProductoMenu("Hamburguesa 1", 100));
        itemsCombo.add(new ProductoMenu("Hamburguesa 2", 150));
        Combo combo = new Combo("Combo 1", 0.2, itemsCombo);

        String textoFactura = combo.generarTextoFactura();

        assertEquals("Combo 1: 200", textoFactura);
    }
}
