package testing;

import modelo.*;

public class ProductoMock extends Producto
{
	 private String nombre;
	 private int precio;

	 public ProductoMock(String nombre, int precio) {
	     this.nombre = nombre;
	     this.precio = precio;
	 }

	 @Override
	 public String getNombre() 
	 {
	     return nombre;
	 }
	    

	 @Override
	 public int getPrecio()
	 {
	     return precio;
	 }

	 @Override
	 public String generarTextoFactura() 
	 {
	     return getNombre() + ":" + getPrecio();
	 }
}
