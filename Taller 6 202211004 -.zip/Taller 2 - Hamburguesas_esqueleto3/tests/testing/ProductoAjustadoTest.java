package testing;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;

import modelo.*;

public class ProductoAjustadoTest {

	@Test
    public void testGetPrecio_BaseWithoutIngredients() {
        ProductoMenu base = new ProductoMenu("Base", 100);
        ProductoAjustado producto = new ProductoAjustado(base, new ArrayList<>(), new ArrayList<>());
        assertEquals(100, producto.getPrecio());
    }

    @Test
    public void testGetPrecio_BaseWithAddedIngredients() {
        ProductoMenu base = new ProductoMenu("Base", 100);
        ArrayList<Ingredientes> agregados = new ArrayList<>();
        agregados.add(new Ingredientes("Ingredient1", 10));
        agregados.add(new Ingredientes("Ingredient2", 20));
        ProductoAjustado producto = new ProductoAjustado(base, agregados, new ArrayList<>());
        assertEquals(130, producto.getPrecio());
    }

    @Test
    public void testGetPrecio_BaseWithRemovedIngredients() {
        ProductoMenu base = new ProductoMenu("Base", 100);
        ArrayList<Ingredientes> eliminados = new ArrayList<>();
        eliminados.add(new Ingredientes("Ingredient1", 10));
        eliminados.add(new Ingredientes("Ingredient2", 20));
        ProductoAjustado producto = new ProductoAjustado(base, new ArrayList<>(), eliminados);
        assertEquals(70, producto.getPrecio());
    }

    @Test
    public void testGenerarTextoFactura_BaseWithoutIngredients() {
        ProductoMenu base = new ProductoMenu("Base", 100);
        ProductoAjustado producto = new ProductoAjustado(base, new ArrayList<>(), new ArrayList<>());
        assertEquals("Base:100", producto.generarTextoFactura());
    }

    @Test
    public void testGenerarTextoFactura_BaseWithAddedIngredients() {
        ProductoMenu base = new ProductoMenu("Base", 100);
        ArrayList<Ingredientes> agregados = new ArrayList<>();
        agregados.add(new Ingredientes("Ingredient1", 10));
        agregados.add(new Ingredientes("Ingredient2", 20));
        ProductoAjustado producto = new ProductoAjustado(base, agregados, new ArrayList<>());
        assertEquals("Base con Ingredient1,Ingredient2:130", producto.generarTextoFactura());
    }

    @Test
    public void testGenerarTextoFactura_BaseWithRemovedIngredients() {
        ProductoMenu base = new ProductoMenu("Base", 100);
        ArrayList<Ingredientes> eliminados = new ArrayList<>();
        eliminados.add(new Ingredientes("Ingredient1", 10));
        eliminados.add(new Ingredientes("Ingredient2", 20));
        ProductoAjustado producto = new ProductoAjustado(base, new ArrayList<>(), eliminados);
        assertEquals("Base sin Ingredient1,Ingredient2:70", producto.generarTextoFactura());
    }

}
