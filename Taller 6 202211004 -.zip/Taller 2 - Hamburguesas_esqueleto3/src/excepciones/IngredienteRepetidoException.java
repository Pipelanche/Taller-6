package excepciones;

import modelo.Ingredientes;

public class IngredienteRepetidoException extends HamburguesaException {
	public IngredienteRepetidoException(Ingredientes ingrediente) {
	        super("Durante la carga, se encontró que el ingrediente " + ingrediente.getNombre() + " está repetido.");
	    }
	}
