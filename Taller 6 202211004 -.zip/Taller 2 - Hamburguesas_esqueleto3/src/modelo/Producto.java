package modelo;

public abstract class Producto{
	public abstract int getPrecio();
	public abstract String generarTextoFactura();
	public abstract String getNombre();}
